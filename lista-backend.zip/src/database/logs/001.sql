--add new column category
Alter table public.product
add column category varchar(30);